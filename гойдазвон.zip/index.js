const http = require('http');
const WebSocket = require('ws');
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Используем 0.0.0.0 по умолчанию для доступа как изнутри, так и извне
const host = '0.0.0.0';
const port = 3001;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Инициализация базы данных
const db = new sqlite3.Database('users.db', (err) => {
    if (err) {
        console.error("Ошибка подключения к базе данных:", err.message);
        return;
    }
    console.log('Подключение к базе данных прошло успешно');
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    `);
});

// Логика регистрации
app.post('/register', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).send("Введите email и пароль");
    }
    db.run('INSERT INTO users (email, password) VALUES (?, ?)', [email, password], function (err) {
        if (err) {
            console.error("Ошибка регистрации:", err.message);
             if(err.message.includes('UNIQUE')){
                  return res.status(400).send("Пользователь с таким email уже существует")
            }
            return res.status(500).send("Ошибка регистрации")
         }
         console.log("Зарегистрирован пользователь:", email);
         res.status(200).send("OK");
    });
});

// Логика входа
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).send("Введите email и пароль");
    }
    db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
        if (err) {
            console.error("Ошибка входа:", err.message);
            return res.status(500).send("Ошибка входа");
        }
        if (row && row.password === password) {
            console.log("Успешный вход:", email)
            res.send("Вы вошли в систему!");
        } else {
            res.status(401).send("Неверный email или пароль");
        }
    });
});

// Добавим обработчик GET запроса на '/login'
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Добавим обработчик GET запроса на '/register'
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'))
});


// WebSocket
wss.on('connection', ws => {
    console.log('Client connected');

    ws.on('message', message => {
        console.log(`Received message: ${message}`);
        ws.send(`Server received: ${message}`);
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

// Запуск сервера
server.listen(port, host, () => {
    console.log(`Server running at http://${host}:${port}/`);
});