 async function handleLogin() {
     const email = document.getElementById('email').value;
     const password = document.getElementById('password').value;
     const errorMessageDiv = document.getElementById('error-message');
     errorMessageDiv.textContent = "";
      if (!email) {
          errorMessageDiv.textContent = "Введите email";
          return;
      }
      if (!password) {
           errorMessageDiv.textContent = "Введите пароль";
            return;
      }
      if(!isValidEmail(email)){
          errorMessageDiv.textContent = "Неверный формат email";
          return;
    }
        try{
             const response = await fetch('/login', {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/x-www-form-urlencoded',
               },
                body: new URLSearchParams({
                    email: email,
                   password: password,
               }),
           });
             if(response.ok){
                 const data = await response.text();
                 if (data.includes('Вы вошли в систему!')) {
                     window.location.href = '/profile'
                 } else{
                    errorMessageDiv.textContent =  data
                 }
             }else {
                errorMessageDiv.textContent = 'Неизвестная ошибка'
           }
       }catch(error){
           errorMessageDiv.textContent = 'Возникла ошибка!'
        console.error("Fetch error:", error);
       }
   }
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
   }

