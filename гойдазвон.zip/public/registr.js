  async function handleRegistration() {
       const email = document.getElementById('email').value;
       const password = document.getElementById('password').value;
       const errorMessageDiv = document.getElementById('error-message');
       errorMessageDiv.textContent = "";
      if (!email) {
           errorMessageDiv.textContent = "Введите email";
             return;
         }
         if (!password) {
              errorMessageDiv.textContent = "Введите пароль";
             return;
         }
        if(!isValidEmail(email)){
            errorMessageDiv.textContent = "Неверный формат email";
             return;
        }
      try{
            const response = await fetch('/register', {
             method: 'POST',
             headers: {
                 'Content-Type': 'application/x-www-form-urlencoded',
             },
              body: new URLSearchParams({
                  email: email,
                 password: password,
             }),
           });
          if(response.ok){
            window.location.href = '/login';
        }else{
           const data = await response.text();
            errorMessageDiv.textContent = data
         }
       }catch(error){
           errorMessageDiv.textContent = "Возникла ошибка!"
         console.error("Fetch error:", error);
      }
  }
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
 }